#include "gpio.h"
#include "printf.h"
#include "i2c.h"
#include "LSM6DS33.h"
#include "sensor.h"
#include "gl.h"
#include "gpio_extra.h"
#include "uart.h"
#include "timer.h"

const unsigned int trigger = GPIO_PIN16;
const unsigned int echo = GPIO_PIN18;

extern int SCREENWIDTH;
extern int SCREENHEIGHT;
extern color_t PADDLE;             //color of paddle
extern color_t BACKGROUND; 

unsigned int get_distance(void) {
	// write hi for 10usec
	gpio_write(trigger, 1); 
	timer_delay_us(10);
	gpio_write(trigger, 0); 

	unsigned start = timer_get_ticks();
	timer_delay_us(149); // wait til device settles: 148 = time to go one inch

	while(gpio_read(echo) == 0)
		;
	while(gpio_read(echo) == 1)
		;

	unsigned end = timer_get_ticks();

	// speed of sound is 340M/sec
	// ((340M/S / 2) * 39.37inch / meter) / 10^6 = inch/usec = 149
	return (end - start) / 149;
}

sensor_object_t sensor_init(const unsigned lsm6ds33_address){
	lsm6ds33_init(lsm6ds33_address);	

	sensor_object_t player;
	player.x = 0;
	player.y = SCREENHEIGHT/2; 

	player.dx = 0;
	player.dy = 0;

	return player;
}

sensor_object_t sonar_init(){
	gpio_set_output(trigger);
	gpio_set_input(echo);
	gpio_set_pulldown(echo);

	sensor_object_t player;

	player.x = 0;
	player.y = get_distance(); 

	player.dx = 0;
	player.dy = 0;

	return player;
}

sensor_object_t updatesonarpos(sensor_object_t player){
	unsigned int distance = get_distance();
	//printf("distance = %d inches\n", distance);
	sensor_object_t updatedplayer;
	updatedplayer.dx=0;
	updatedplayer.x = player.x;

	if (distance >player.y){
		updatedplayer.dy = -5;
	}
	if (distance < player.y){
		updatedplayer.dy = +5;
	}
	updatedplayer.y = player.y + updatedplayer.dy;
	printf("Change in y:%d\n", updatedplayer.dy);
	return updatedplayer;

}
sensor_object_t updateposition(sensor_object_t player, const unsigned lsm6ds33_address){

	short x, y, z;
	lsm6ds33_read_accelerometer(&x, &y, &z, lsm6ds33_address);

	sensor_object_t updatedplayer;
	updatedplayer.dx = 0;

	updatedplayer.dy = -x/80;

	updatedplayer.x = player.x;

	updatedplayer.y = player.y + updatedplayer.dy;
	return updatedplayer;

}

