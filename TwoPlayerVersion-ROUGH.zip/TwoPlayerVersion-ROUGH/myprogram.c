#include "sensor.h"
#include "pi.h"
#include "strings.h"
#include "gpio.h"
#include "ball.h"
#include "paddle.h"
#include "gl.h"
#include "uart.h"
#include "mymodule.h"
#include "timer.h"
#include "printf.h"
#include "i2c.h"
#include "LSM6DS33.h"

//This is 0x6A

const unsigned ls6mds33_address1 = 0b1101010;
//This is 0x6b
const unsigned lsm6ds33_address2 = 0b1101011; // this is for the gyro/accel;

static int rightscore = 0;
static int leftscore = 0;

int SCREENWIDTH = 640;
int SCREENHEIGHT = 512;
color_t BALL = GL_RED;
color_t PADDLE = GL_BLACK;
color_t BACKGROUND = GL_WHITE;

void display_welcome(void){

	gl_draw_string(215, 236, "LET'S PLAY PONG", GL_BLACK);
	gl_draw_rect(215, 256, 14*15, 36, GL_RED);
	gl_draw_string(222, 266, "CLICK TO START", GL_WHITE);
	gl_swap_buffer();
}

void display_go(void){
	gl_draw_string(299, 248, "GO!", GL_BLACK);
	gl_swap_buffer();
}
void display_bye(void){
	gl_draw_rect(282, 238, 76, 36, GL_RED);
	gl_draw_string(292, 248, "BYE!", GL_WHITE);
	gl_swap_buffer();
}
void display_play_to_win(void){
	gl_draw_rect(168, 238, 304, 36, GL_RED);
	gl_draw_string(173,248, "PLAY TO WIN 9 POINTS.", GL_WHITE);
	gl_swap_buffer();
}

void display_winnerofround(int winner){

	if (winner == 1){

                gl_draw_string(226, 226, "RIGHT WINS THIS ROUND!", GL_BLACK);
        }
        
        else {
                gl_draw_string(226, 226, "LEFT WINS THIS ROUND!", GL_BLACK);
        }

	char rscore = rightscore +48;

        char buf[100];

        memset(buf, 0x77, 100); 
	snprintf(buf, 20, "%s: %c!", "RIGHT SCORED", rscore);


	char lscore = leftscore +48;

        char buf1[100];

        memset(buf1, 0x77, 100);
        snprintf(buf1, 20, "%s: %c!", "LEFT SCORED", lscore);

	gl_draw_string(208, 246, buf, GL_BLACK);
	gl_draw_string(215,266, buf1, GL_BLACK);
        gl_swap_buffer();

}
void display_winner(int winner){

	if (winner == 1){

		gl_draw_string(243, 248, "RIGHT WINS!", GL_BLACK);
	}
	
	else {
		gl_draw_string(315, 248, "LEFT WINS!", GL_BLACK);
	}
	gl_swap_buffer();
}
void display_points(void){
	char score = rightscore +48;

	char buf[100];
	size_t bufsize = sizeof(buf);

	memset(buf, 0x77, sizeof(buf)); // init contents with known value


	snprintf(buf, 20, "%s: %c!", "YOU'VE SCORED", score);
	gl_draw_string(201, 206, buf, GL_BLACK);
	gl_draw_string(166, 231, "BETTER LUCK NEXT TIME!", GL_BLACK);
	gl_draw_rect(182, 256, 14*19+10, 36, GL_RED);
	gl_draw_string(187, 266, "CLICK TO PLAY AGAIN", GL_WHITE);
	gl_swap_buffer();


}
//check if the ball has hit the given paddle
bool check_hit_paddle(ball_t ball, paddle_object paddle)
{
	//check ball x and y are top layer of paddle
	int mid_height = paddle.height/2;
	int mid_width = paddle.width/2;
	int multiplier = 1;

	//if ball is moving to right
	if (ball.vx > 0) {
		multiplier = -1;;
	}
	//edge of ball touching paddle
	mid_width *= multiplier;
	int ball_side_x = ball.x - (ball.radius * multiplier);
	int ball_top_y = ball.y - ball.radius;
	int ball_bottom_y = ball.y + ball.radius;

	//if center edge of ball is on paddle
	if (gl_read_pixel(ball_side_x, ball.y) == PADDLE) {
		return true;
	}

	/*
	   int paddle_edge = paddle.x + mid_width;

	   if ((ball_edge >= paddle_edge - 1) && (ball_edge <= paddle_edge + 1)) {
	   if ((ball.y + ball.radius > paddle.y - mid_height) && (ball.y - ball.radius < paddle.y + mid_height)) {
	   return true;
	   }
	   }*/
	return false;
}

void main(void)
{

	//First Initialize everything.
	uart_init();
	timer_init();
	gpio_init();
	i2c_init();
	gl_init(SCREENWIDTH, SCREENHEIGHT, GL_DOUBLEBUFFER);
	gl_clear(BACKGROUND); //background is white

	gpio_set_function(GPIO_PIN10, GPIO_FUNC_INPUT);
	gpio_set_function(GPIO_PIN9, GPIO_FUNC_INPUT);
	
	//Display welcome screen while waiting for a click.
	display_welcome();
	while(gpio_read(GPIO_PIN10)==1 || gpio_read(GPIO_PIN9)==1){}

	//Start game.
	gl_clear(BACKGROUND);

	display_go();
	timer_delay_ms(500);
	
	gl_clear(BACKGROUND);
	sensor_object_t person1 = sensor_init(0b1101010);
	sensor_object_t person2 = sensor_init(lsm6ds33_address2);

	//ball starts in center
	ball_t ball = reset_ball();

	//creates two paddles for player 1 and 2
	paddle_object paddle1 = create_paddle(1);
	paddle_object paddle2 = create_paddle(2);

	while (1) {

		//draw contents 
		draw_ball(ball.x, ball.y);
		draw_paddle(paddle1);
		draw_paddle(paddle2);
		gl_swap_buffer();

		//delay
		timer_delay_ms(5);
		/*
		//save current paddle and ball to erase later 
		paddle_object cur_pad1 = paddle1;
		paddle_object cur_pad2 = paddle2;
		int cur_bally = ball.y;
		int cur_ballx = ball.x;
		 */
		//move ball
		ball.x += ball.vx;
		ball.y += ball.vy;
		ball = check_ball_edges(ball);

		if (ball_check_hit_right(ball)) {
			//ball.vx *= -1;
			leftscore+=1;

			gl_clear(BACKGROUND);
			display_winnerofround(0);
			timer_delay_ms(1000);
			
			gl_clear(BACKGROUND);
			ball = reset_ball();
			timer_delay_ms(100);
		}
		if (ball_check_hit_left(ball)) {
			rightscore +=1;

			gl_clear(BACKGROUND);
			display_winnerofround(1);
			timer_delay_ms(1000);
			
			gl_clear(BACKGROUND);
			ball = reset_ball();
			timer_delay_ms(100);
			// ball.vx *= -1;
		}

		//Update person's location based on sensor inputs.
		person1 = updateposition(person1, 0b1101010);
		person2 = updateposition(person2, lsm6ds33_address2);

		//move paddles --> right now this is automated
		paddle1.y = paddle1.y + person1.dy;
		paddle2.y = paddle2.y + person2.dy;
		
		//check if paddles have hit top or bottom 
		if(check_paddle_top(paddle1)) {
			paddle1.y = paddle1.height/2;
		}
		if(check_paddle_top(paddle2)) {
			paddle2.y = paddle2.height/2;
		}
		if(check_paddle_bottom(paddle1)) {
			paddle1.y = SCREENHEIGHT - (paddle1.height/2);
		}
		if(check_paddle_bottom(paddle2)) {
			paddle2.y = SCREENHEIGHT - (paddle2.height/2);
		}

		//check if ball hits paddles 
		if (ball.vx < 0) {
			if (check_hit_paddle(ball, paddle1)) {
				//printf("ball hit left paddle\n");
				ball.vx *= -1;
			}
		}
		else {
			if (check_hit_paddle(ball, paddle2)) {
				//printf("ball hit right paddle\n");
				ball.vx *= -1;
			}
		}	    

		//Check if the player on the right of the screen has won. If so, terminate game.
		if (rightscore == 9){
			gl_clear(BACKGROUND);
			display_winner(1);
			timer_delay_ms(10000);
			gl_clear(BACKGROUND);
			display_bye();
			timer_delay_ms(5000);
			pi_reboot();	
		}

		if (leftscore == 9){
			gl_clear(BACKGROUND);
                        display_winner(0);
                        timer_delay_ms(10000);
                        gl_clear(BACKGROUND);
                        display_bye();
                        timer_delay_ms(5000);
                        pi_reboot();

		}
		gl_clear(BACKGROUND);
	}

}



