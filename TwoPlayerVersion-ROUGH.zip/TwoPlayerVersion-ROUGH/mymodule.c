/*#include "gl.h"
#include "printf.h"
//static const int SCREENWIDTH = 640;
//static const int SCREENHEIGHT = 512;
static const int padWIDTH = 5;
static const int padHEIGHT = 10;
static const color_t colour = GL_AMBER;

typedef struct {
	int x, y;

}paddle_object;

paddle_object paddle_create(int playerno){
	paddle_object returnpad;
	returnpad.y=10;
	printf("starting ball at %d\n", returnpad.y);
	if (playerno%2 == 1){
		returnpad.x = 10;
	}
	else {
		returnpad.x = 500;
	}
	return returnpad;

}

paddle_object paddle_read_event(paddle_object paddle){
	paddle.y+=20;
	printf("IN function: paddle-y:%d\n", paddle.y);
	return paddle;
}
 int dy, int updown){
	int cury = paddle.y;
	if (updown == 1){
		if (cury+dy <= SCREENHEIGHT){
			printf("changing paddle\n");
			printf("%d\n", paddle.y);	
			paddle.y=paddle.y+dy;
			printf("%d\n", paddle.y);
		}
	}

	if (updown == 0){
		if (paddle.y-dy >=0){
			paddle.y -= dy;
		}
	}

}

void draw_paddle(paddle_object paddle){
	gl_draw_rect(paddle.x, paddle.y, padWIDTH, padHEIGHT, colour);
	gl_swap_buffer();
}
*/
