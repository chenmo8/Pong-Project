#include "ball.h"
#include "paddle.h"
#include "gl.h"
#include "uart.h"
#include "mymodule.h"
#include "timer.h"
#include "printf.h"
#include "sensor.h"
#include "tof.h"

int SCREENWIDTH = 640;
int SCREENHEIGHT = 512;
color_t BALL = GL_RED;
color_t PADDLE = GL_BLACK;
color_t BACKGROUND = GL_WHITE;
static const int BUTTON = GPIO_PIN9;

//check if the ball has hit the given paddle
bool check_hit_paddle(ball_t ball, paddle_object paddle)
{
	//check ball x and y are top layer of paddle
	int mid_height = paddle.height/2;
	int mid_width = paddle.width/2;
	int multiplier = 1;

	//if ball is moving to right
	if (ball.vx > 0) {
		multiplier = -1;;
	}
	//edge of ball touching paddle
	mid_width *= multiplier;
	int ball_side_x = ball.x - (ball.radius * multiplier);
	int ball_top_y = ball.y - ball.radius;
	int ball_bottom_y = ball.y + ball.radius;

	//if center edge of ball is on paddle
	if (gl_read_pixel(ball_side_x, ball.y) == PADDLE) {
		return true;
	}

	/*
	   int paddle_edge = paddle.x + mid_width;
	   if ((ball_edge >= paddle_edge - 1) && (ball_edge <= paddle_edge + 1)) {
	   if ((ball.y + ball.radius > paddle.y - mid_height) && (ball.y - ball.radius < paddle.y + mid_height)) {
	   return true;
	   }
	   }*/
	return false;
}

void welcome(void){


	gl_draw_string(100, 250, "WECLOME TO THE GAME", GL_BLUE);
	gl_draw_string(100, 300, "PRESS BOTH BUTTONS TO START", GL_BLUE);
	//gl_swap_buffer();
}

void handler(unsigned int pc, void *aux_data){
	//sensor1 = readrawchangeinyposition(sensor1);
	printf("%s\n", (char *)aux_data);
	//need to change to make it print(aux_data);
	gpio_check_and_clear_event(BUTTON);
}
void main(void)

{
	uart_init();
	gpio_init();
	//Display start screen.
	gpio_set_function(GPIO_PIN10, GPIO_FUNC_INPUT);

	//initialise graphics library
	gl_init(SCREENWIDTH, SCREENHEIGHT, GL_SINGLEBUFFER);
	gl_clear(GL_WHITE); //background is white

	//Display Welcome Screen.
	gpio_set_function(GPIO_PIN10, GPIO_FUNC_INPUT);
	welcome();
	printf("done drawing\n");
	printf("%d\n", gpio_read(GPIO_PIN10));	
	while(gpio_read(GPIO_PIN10)==1){}//printf("%d\n", gpio_read(GPIO_PIN20));}
	gl_clear(GL_WHITE);

	//Enable Interrupts.
	interrupts_init();
	interrupts_init();

	char *aux_data = "BUTTON has interrupt mojo\n";
	printf("%d\n", gCount);
	gpio_interrupts_init();

	Set gpio stuff.
	gpio_set_input(BUTTON); // configure button
	gpio_set_pullup(BUTTON);

	//Enable detection of desired event(low level for button gpio-while pressed down).
	gpio_enable_event_detection(BUTTON, GPIO_DETECT_LOW_LEVEL);

	//Fn doesn't need to be dispatch / in this example,
	// don't need second level of dispatch because only one button to trigger interrupt.
	//All gpios accounted for in interrupts_gpio3
	//Aux data to pass a message to your handler.

	interrupts_register_handler(INTERRUPTS_GPIO3, handler, (void *)aux_data);
	interrupts_global_enable();




	//ball starts in center
	sensor_object_t sensor1 = sensor_init();
	ball_t ball = reset_ball();

	//creates two paddles for player 1 and 2 
	paddle_object paddle1 = create_paddle(1);
	paddle_object paddle2 = create_paddle(2);

	while (1) {

		//draw contents 
		draw_ball(ball.x, ball.y);
		draw_paddle(paddle1);
		draw_paddle(paddle2);

		//delay
		timer_delay_ms(10);

		//save current paddle and ball to erase later 
		paddle_object cur_pad1 = paddle1;
		paddle_object cur_pad2 = paddle2;
		int cur_bally = ball.y;
		int cur_ballx = ball.x;

		//move ball
		ball.x += ball.vx;
		ball.y += ball.vy;
		ball = check_ball_edges(ball);

		if (ball_check_hit_right(ball)) {
			ball.vx *= -1;
			// ball = reset_ball();
		}
		if (ball_check_hit_left(ball)) {
			//ball = reset_ball();
			ball.vx *= -1;
		}

		//sensor1 = readrawchangeinyposition(sensor1);
		//move paddles --> right now this is automated 
		paddle1.y = ball.y+5; //;+ screenchangeinposition(sensor1);
		paddle2.y = ball.y; 

		//check if paddles have hit top or bottom 

		if(check_paddle_top(paddle1)) {
			paddle1.y = paddle1.height/2;
		}
		if(check_paddle_top(paddle2)) {
			paddle2.y = paddle2.height/2;
		}
		if(check_paddle_bottom(paddle1)) {
			paddle1.y = SCREENHEIGHT - (paddle1.height/2);
		}
		if(check_paddle_bottom(paddle2)) {
			paddle2.y = SCREENHEIGHT - (paddle2.height/2);
		}

		//check if ball hits paddles 
		if (ball.vx < 0) {
			if (check_hit_paddle(ball, paddle1)) {
				printf("ball hit left paddle\n");
				ball.vx *= -1;
			}
		}
		else {
			if (check_hit_paddle(ball, paddle2)) {
				printf("ball hit right paddle\n");
				ball.vx *= -1;
			}
		}	    

		//clear balls and paddles 
		clear_paddle(cur_pad1);
		clear_paddle(cur_pad2);
		clear_ball(cur_ballx, cur_bally);
	}

}

