#ifndef _MY_MODULE_H

/*
typedef struct{
        int x, y;

} paddle_object;


paddle_object paddle_create(int playerno);

paddle_object paddle_read_event(paddle_object paddle);//, int dy, int updown);
void draw_paddle(paddle_object paddle);
*/
#endif
