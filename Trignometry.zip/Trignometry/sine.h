/*table containing values of sine(0) to sine(90) for all integers
 all values given to 4 significant figures*python code to generate:
 *
 * import math
 * for i in range(10):
    num = float((math.sin(i)))
    rounded = float('%.4g' % num)
    print(rounded);
 */



float sine(int angle);

float cos(int angle);
